<script setup lang="ts">
import TodosTodos from '@/components/TodosTodos.vue'
</script>

<template>
  <main>
    <TodosTodos />
  </main>
</template>
